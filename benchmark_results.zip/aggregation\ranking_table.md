| Method | Avg Rank (↓) | Cells | Wins |
|---|---:|---:|---:|
| tpe | 1.400 | 30 | 19 |
| cats | 1.700 | 30 | 11 |
| random | 2.900 | 30 | 0 |
